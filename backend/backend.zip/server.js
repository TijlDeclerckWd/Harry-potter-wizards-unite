const app = require("./app");
const debug = require("debug")("node-angular");
const http = require("http");
const socketIO = require('socket.io');
const jwtDecode = require('jwt-decode')
const {Users} = require("./classes/users");

const normalizePort = val => {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
};

const onError = error => {
  if (error.syscall !== "listen") {
    throw error;
  }
  const bind = typeof addr === "string" ? "pipe " + addr : "port " + port;
  switch (error.code) {
    case "EACCES":
      console.error(bind + " requires elevated privileges");
      process.exit(1);
      break;
    case "EADDRINUSE":
      console.error(bind + " is already in use");
      process.exit(1);
      break;
    default:
      throw error;
  }
};

const onListening = () => {
  const addr = server.address();
  const bind = typeof addr === "string" ? "pipe " + addr : "port " + port;
  debug("Listening on " + bind);
};

const port = normalizePort(process.env.PORT || "3000");
app.set("port", port);

const server = http.createServer(app);
const io = socketIO(server);
let users = new Users();

server.on("error", onError);
server.on("listening", onListening);
server.listen(port);

io.on('connection', function(socket) {
  var token = socket.handshake.query.token;

  var decodedToken = jwtDecode(token);

  console.log('user connected');
  users.removeUser(socket.id);
  socket.join('general');

  users.addUser(socket.id, decodedToken.user.username, 'general');

  io.to('general').emit('updateUserList', users.getUserList('general'));
  socket.emit('message', {
      message: `Welcome to the chat ${decodedToken.user.username}`,
      fullName:'Admin'
  });

  socket.broadcast.to('general').emit('message', {
      message: `${decodedToken.user.username} has joined the group`,
      fullName: 'Admin'
  });

socket.on('join', function(params) {
  var decodedToken = jwtDecode(params.token);

  socket.join(params.room);
  users.removeUser(socket.id);
  users.addUser(socket.id, decodedToken.user.username, params.room);

  io.to(params.room).emit('updateUserList', users.getUserList(params.room));
  socket.emit('message', {
      message: `Welcome to the chat ${decodedToken.user.username}`,
      fullName:'Admin'
  });
  socket.broadcast.to(params.room).emit('message', {
      message: `${decodedToken.user.username} has joined the group`,
      fullName: 'admin'
  })

});
//    socket.emit here will just send the message to the window that loads the page
//     socket.emit('message',{
//         to: "",
//         from: "",
//         message: "Welcome"
//     });

  //socket.broadcast stuurt naar iedereen buiten jezelf
  // socket.broadcast.emit('message', {
  //     from: "Tijl",
  //     message: "Welcome"
  // });

  // socket.on('send-location', function(data){
  //     io.emit('message', {
  //         message: data.lat + ', ' + data.lng
  //     })
  // });


  socket.on('disconnect', function () {
      console.log('connection ended');
      var user = users.removeUser(socket.id);

      if (user) {
          console.log('user', user);
          io.to(user.room).emit('updateUserList', users.getUserList(user.room));
          io.to(user.room).emit('message', {
              fullName: 'Admin',
              message: `User has left.`
          });
      }
  });

  socket.on('send-message', function (msg) {
      // Io.emit emits to every single connection, socket to everyone but you
      var user = users.getUser(socket.id);

      io.to(user.room).emit('message', {
          message: msg.message,
          user: user.name,
          fullName: decodedToken.user.firstName + ' ' + decodedToken.user.lastName,
          time: new Date().getTime()
      });
      // socket.broadcast.emit('newMessage', function(msg){
      //  msg: content
      // })
  });
});




