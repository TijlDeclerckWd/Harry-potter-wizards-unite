var express = require('express');
var router = express.Router();
var async = require('async');
var User = require('../models/user');
var Conversation = require('../models/conversation');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var multer = require('multer');
var path = require('path');

var storage = multer.diskStorage(
    {
        destination: function(req, file, cb) { cb(null, './assets/app/images/profile-pictures')},
        filename: function(req, file, cb) { cb(null, Date.now() + path.extname(file.originalname))}
    }
);

var upload = multer({ storage: storage });


router.get('/checkEmailUniqueness/:email', function(req, res) {
   User.findOne({'email': { $regex: new RegExp("^" + req.params.email.toLowerCase() + "$", "i") }})
       .exec(function(err, user){
           if (err) {
               return res.status(500).json({
                   title: "An error occurred",
                   error: err
               })
           }
           else if (!user) {
               return res.status(200).json({
                       message: 'there is no person with this email address',
                       obj: false
                   }
               )
           }
           res.status(200).json({
               message: "This email address is already taken, please pick another one",
               obj: true
           })
       })
});

router.get('/checkUsername/:username', function(req, res) {
    User.findOne({'username': { $regex: new RegExp("^" + req.params.username.toLowerCase() + "$", "i") }}, function(err, user){
       if (err) {
           return res.status(500).json({
               title: "An error occurred",
               error: err
           })
       }
       else if (!user) {
           return res.status(200).json({
               message: 'there is no person with this username',
               obj: false
               }
           )
       }
       res.status(200).json({
           message: "Someone already has this username, please pick another one",
           obj: true
       })
   })
});

router.get('/getUserData/:userId', function (req, res) {
    console.log('check end path', req.params.userId);

    User.findOne({ '_id': req.params.userId })
        .exec(function (err, user) {
            console.log('user', user);
            if (err) {
                return res.status(500).json({
                    title: "An error occurred",
                    error: err
                })
            }
            res.status(200).json({
                message: "Succesfully retrieved the user data",
                obj: user
            })
        })
})

router.get('/getUserPMs/:userId', function(req, res) {
   Conversation.find({$or: [{user1: req.params.userId}, {user2: req.params.userId}]})
       .populate('messages.from', 'firstName lastName')
       .populate('messages.to', 'firstName lastName')
       .exec(function(err, conversations){
           if (err) {
               return res.status(500).json({
                   title: "An error occurred",
                   error: err
               })
           }
           res.status(200).json({
               message: "successfully received PMs",
               obj: conversations
           })
       })
});

router.post('/sendPM', function(req, res) {
    // We do this so that we always just have to save the conversation one time.
    var theBiggerOne = Number(req.body.currentUserId) >= Number(req.body.destinationUserId) ? req.body.currentUserId : req.body.destinationUserId;
    var theSmallerOne = theBiggerOne === req.body.currentUserId ? req.body.destinationUserId : req.body.currentUserId;

    async.waterfall([
        findConversation,
        addMessageToConversation
    ], function(err, conversation){
        if (err) {
            return res.status(500).json({
                title: "An error occurred",
                error: err
            })
        }
        console.log(conversation);
        res.status(200).json({
            message: "successfully sent PM",
            obj: conversation
        })
    });

    function findConversation(cb){
        Conversation.find({
            $and: [{user1: theBiggerOne}, {user2: theSmallerOne}]}, function (err, conversation) {
            cb(null, conversation)
        })
    }

    function addMessageToConversation(conversation, cb) {
        var newMessage = {
            date: new Date(),
            from: req.body.currentUserId,
            to: req.body.destinationUserId,
            msg: req.body.msg
        };

        console.log('newMessage line', newMessage);
                if (!conversation[0]){
                //    create new conversation
                    var newConversation = new Conversation({
                        user1: theBiggerOne,
                        user2: theSmallerOne,
                        messages: [newMessage]
                    });
                //    save new conversation
                    newConversation.save(function(err, savedNewConversation){
                       console.log('savedNewConversation', savedNewConversation);
                        cb(null, savedNewConversation);
                    })
                } else {
                //    there is already a conversation and we need to add the new message to it
                    console.log(' there was already a conversation', conversation);
                    conversation[0].messages.push(newMessage);
                    conversation[0].save(function(err, savedExistingConversation){
                        cb(null, savedExistingConversation)
                    })
                }
    }
    });

router.post('/signup', function(req, res){
    createNewUser(req.body, function(result){
        if (!result.success){
            res.status(500).json({
                message: "unable to create User",
                obj: result.err
            })
        } else {
            res.status(200).json({
                message: "successfully created new user",
                obj: result.obj
            })
        }
    });
});

// later I will add the appropriate security for the social media logins, for now I'll stick with the google ID
router.post('/signin', function(req, res){
    var hasUserName = true;

    User.findOne({email: req.body.email}, function(err, user){

        if (!user) {
            return res.status(401).json({
                title: 'Login failed: invalid login credentials',
                error: {message: 'Invalid login credentials'}
            });
        }

        // check if given password is the same as the one provided at signup
        if (!bcrypt.compareSync(req.body.password, user.password)) {
            return res.status(401).json({
                title: 'Login failed: invalid login credentials ',
                error: {message: 'Invalid login credentials'}
            })
        }

        // Obtain the token that will later be used at the front-end
        var token = jwt.sign({user: user}, 'secret', {expiresIn: 72000});

        // Update the last time this user signed in
        user.lastLogin = new Date();

        user.save(function (err, user) {
            if (err) {
                return res.status(500).json({
                    title: "An error occurred",
                    error: err
                })
            }
            res.status(200).json({
                message: 'Successfully logged in',
                token: token,
                fullName: user.firstName + ' ' + user.lastName,
                hasUsername: hasUserName
            });
        });
    });
});

router.post('/submitUsername', function(req, res) {
    User.findOne({'_id': req.body.currentUserId}, function(err, user){
        user.username = req.body.input;
        user.save(function(err, user){
            if (err) {
                return res.status(500).json({
                    title: "An error occurred",
                    error: err
                })
            }
            console.log('user', user);
            res.status(200).json({
                message: "successfully received PMs",
                obj: user
            })
        })
    })
});

router.post('/uploadProfilePicture/:userId', upload.single('fileKey'), function(req, res) {
    User.findOne({'_id': req.params.userId}, function(err, user){
        console.log('user test 1', user);
        user.profilePicture.name = req.file.filename;
        console.log('req.file.filename', req.file.filename);
        user.profilePicture.uploaded = true;
        user.save(function(err, user){
            if (err) {
                return res.status(500).json({
                    title: 'An error occurred',
                    error: err
                });
            }
            res.status(200).json({
                message: 'User created',
                imageUrl: user.profilePicture.name
            });
        })
    })
})

//this function is different depending on whether people log in with social media or with username/password
function createNewUser(userData, onComplete){
    var user;

    user = new User({
            firstName: userData.firstName,
            lastName: userData.lastName,
            username: userData.username,
            password: bcrypt.hashSync(userData.password, 10),
            email: userData.email,
            birthDate: userData.birthDate,
            country: userData.country,
            registerDate: new Date()
        });


    user.save(function(err, user) {
        if (err) {
            onComplete({
                success: false,
                err: err
            })
        }
        else {
            onComplete({
                success: true,
                obj:user
            })
        }
    });
}

module.exports = router;