var express = require('express');
var router = express.Router();
var async = require("async");
var jwtDecode = require('jwt-decode');
var Location = require('../models/location');

router.get('/getThreeClosestPlayers/:userId', function(req, res) {

    console.log('reached back-end');

    var userId = req.params.userId;

    async.waterfall([
       findOwnLocationObject,
       findClosestPlayers
    ], function(err, fiveClosest){
        if (err) {
            res.status(500).json({
                title: "An error occurred",
                error: err
            })
        }
        res.status(200).json({
            message: "successfully retrieved the three closest players",
            obj: fiveClosest
        })
    });

    function findOwnLocationObject(cb){
        Location.findOne({'user': userId}, function(err, CULocationObj) {
            cb(null, CULocationObj);
        });
    }
    function findClosestPlayers(locationUser, cb) {
        var threeClosest = [];
        var locationUserLat = locationUser.latitude;
        var locationUserLng = locationUser.longitude;
        Location.find({})
            .populate('user')
            .exec(function(err, locations){
                locations.forEach(function(location){
                    var distance = getDistanceFromLatLngInKm(locationUserLat, locationUserLng, location.latitude, location.longitude);
                    var distanceObject = {
                        distanceInKMS: distance,
                        locationObj: location
                    };
                    if (threeClosest.length < 4) {
                        threeClosest.push(distanceObject);
                        threeClosest.sort(function(a, b){
                            return b.distanceInKMS - a.distanceInKMS;
                        })
                    } else {
                        var alreadyReplaced = false;

                        threeClosest.forEach(function(currentClosestObj, index){
                            // We only want to replace the highest distance
                            if (distanceObject.distanceInKMS < currentClosestObj.distanceInKMS && alreadyReplaced === false) {
                                threeClosest[index] = distanceObject;
                                // sort the array to let the highest distance be assessed first
                                threeClosest.sort(function(a, b){
                                    return b.distanceInKMS - a.distanceInKMS;
                                });
                                alreadyReplaced = true
                            }
                        });
                    }
                });
                cb(null, threeClosest);
            })
    }
});

router.post('/saveLocation', function(req, res){

    var decodedToken = jwtDecode(req.body.token);

//    Look if the user has already a saved location in the database. If so, change the existing lat and lng, if not create a new one
    Location.findOne({'user': decodedToken.user._id}, function(err, existingLocation) {
        if (err) {
            res.status(500).json({
                title: "An error occurred",
                error: err
            })
        }
        // if the current user has no existing location data, we create new location document
        if (existingLocation === null) {

            var newLocation = new Location({
                latitude: req.body.latitude,
                longitude: req.body.longitude,
                user: decodedToken.user._id
            });

            newLocation.save(function(err, newLoc){
                console.log('completed the save');
                if (err) {
                    return res.status(500).json({
                        title: "An error occurred",
                        error: err
                    })
                }
                console.log('newLoc', newLoc);
                return res.status(200).json({
                    message: "succesfully saved new location",
                    obj: newLoc
                })
            })
        }
        // there was already a location connected to this user and now
        // we're changing the coordinates
        if (existingLocation){
            existingLocation.latitude = req.body.latitude;
            existingLocation.longitude = req.body.longitude;

            existingLocation.save(function (err, changedLoc) {
                if (err) {
                    res.status(500).json({
                        title: "An error occurred",
                        error: err
                    })
                }
                res.status(200).json({
                    message: "succesfully changed location",
                    obj: changedLoc
                })
            });
        }
    });
});

router.get('/getLocations/:token', function(req, res) {

    var decodedToken = jwtDecode(req.params.token);

    async.waterfall([
        getAllLocations,
        filterOutOwnLocation
    ], function(err, locationCollection, myLocation) {
        if (err) {
            return res.status(500).json({
                title: "An error occurred",
                error: err
            })
        }
        res.status(200).json({
            message: "successfully retrieved all locations",
            obj: {
                locationCollection: locationCollection,
                myLocation: myLocation
            }
        })
    });

    function getAllLocations(cb) {
        Location.find({})
            .populate({
                path: 'user'
            })
            .exec(function(err, locationDocs){
                cb(null, locationDocs)
            })
    }

    function filterOutOwnLocation( locations, cb){
        console.log('locationDocs', locations);
        var myDoc = locations.filter(function(doc){
            console.log('doc', doc);

            return doc.user._id == decodedToken.user._id
        });
        cb(null, locations, myDoc)
    }
});

function getDistanceFromLatLngInKm(lat1,lon1,lat2,lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2-lat1);  // deg2rad below
    var dLon = deg2rad(lon2-lon1);
    var a =
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
        Math.sin(dLon/2) * Math.sin(dLon/2)
    ;
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    var d = R * c; // Distance in km
    return d;
}

function deg2rad(deg) {
    return deg * (Math.PI/180)
}


module.exports = router;
