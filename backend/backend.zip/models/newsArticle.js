var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var schema = new Schema({
    htmlCode: String,
    date: {type: Date, default: Date.now}
}, { usePushEach: true });

module.exports = mongoose.model('NewsArticle', schema);