var express = require('express');
var router = express.Router();
var ForumPost = require("../models/forumPost");
var async = require("async");
var User = require('../models/user');
var jwtDecode = require('jwt-decode');
var ForumSection = require('../models/forumSection');
var ForumReply = require('../models/forumReply');
var ForumCount = require('../models/forumCount');
var SubViewCount = require('../models/subViewCount');

router.post('/addPost', function(req, res){
    var decodedToken = jwtDecode(req.body.token);

    var newPost = new ForumPost({
        user: decodedToken.user._id,
        title: req.body.title,
        content: req.body.content,
        section: req.body.section.toLowerCase()
    });

    console.log(newPost);

    async.waterfall([
        saveNewPost,
        addPostToUser,
        addPostToSectionAndEditLastPost
    ], function(err, post, user){
        if (err) {
            res.status(500).json({
                title: "An error occurred",
                error: err
            })
        }
        res.status(200).json({
            message: "successfully added forum message",
            obj: {
                title: post.title,
                user: {
                    username: user.username
                },
                totalViews: 0,
                totalReplies: 0,
                replies: post.replies
            }
        })

    });

    function saveNewPost(cb){
        newPost.save(function(err, post) {
            cb(null, post)
        });
    }

    function addPostToUser(post, cb){
        console.log(post);

        // REMINDER: I have to erase earlier made additions to this user method that are not longer valid
        User.findOne({'_id': post.user}, function(err, user){
            console.log(user);
            user.forumPosts.push(post._id);
            user.save(function(err, user){
                cb(null, post, user);
            });
        });
    }

    function addPostToSectionAndEditLastPost(post, user, cb) {
        console.log(post.section);
        ForumSection.findOne({'name': post.section}, function (err, section) {
            console.log(section);
            section.posts.push(post._id);
            section.lastPost = {date: post.date, name: user.username, title: post.title, id: post._id};
            section.save(function(err, section){
                cb(null, post, user)
            });
        });
    }
});

router.post('/addReply', function(req,res){

    var decodedToken = jwtDecode(req.body.token);

    var newReply = new ForumReply({
        user: decodedToken.user._id,
        post: req.body.postId,
        content: req.body.content,
        quotes: req.body.quotes
    });

    async.waterfall([
       saveNewReplyAndPopulateUser,
       addNewReplyToPost,
        addNewReplyToUser,
    ], function(err, reply){
        if (err) {
            res.status(500).json({
                message: 'An error has occured',
                obj: err
            })
        }
        console.log('final reply', reply);
        res.status(200).json({
            message: "you have successfully added a new reply",
            obj: reply
        })
    });

    function saveNewReplyAndPopulateUser(cb){
        newReply.save(function(err, reply){
            reply.populate('user', 'username forumPosts forumReplies registerDate date', function(err, reply){
                cb(null, reply)
            });
        });
    }

    function addNewReplyToPost(reply, cb) {
        ForumPost.findOne({'_id': req.body.postId}, function(err, post){
            post.replies.push(reply._id);
            post.save(function(err, post){
                cb(null, reply);
            });
        });
    }

    function addNewReplyToUser(reply, cb) {
        User.findOne({'_id': reply.user}, function(err, user){
            user.forumReplies.push(reply._id);
            user.save(function(err, user){
                cb(null, reply)
            })
        })
    }
});

router.delete('/deleteReply/:replyId/:postId/:userId', function(req, res) {

    var replyId = req.params.replyId;
    var postId = req.params.postId;
    var userId = req.params.userId;

    async.parallel([
        deleteFromForumReplies,
        deleteFromForumPosts,
        deleteFromUser
    ], function(err, result){
        if (err) {
            res.status(500).json({
                message: 'An error has occured',
                obj: err
            })
        }
        console.log('result', result);
        res.status(200).json({
            message: "you have successfully added a new reply",
            obj: result
        })
    });

    function deleteFromForumReplies(cb) {
        ForumReply.findOneAndRemove({'_id': replyId}, function (err, removedObj){
            console.log('removed Obj', removedObj);
            cb(null, removedObj)
    });
    }

    function deleteFromForumPosts(cb) {
        ForumPost.findOne({'_id': postId}, function(err, post){
            var index = post.replies.findIndex(reply => reply._id === replyId)
            console.log('index', index);
            post.replies.splice(index, 1);
            console.log('post post splice', post);
            post.save(function(err, post){
                cb(null, post)
            })
        })
    }

    function deleteFromUser(cb){
        User.findOne({'_id': userId}, function(err, user){
            var index = user.forumReplies.indexOf(replyId);
            user.forumReplies.splice(index, 1);
            user.save(function(err, user){
                cb(null, user)
            })
        })
    }
});

router.put('/editReply', function(req, res){
   async.waterfall([
       findReply,
       saveReply
   ], function(err, reply){
       if (err) {
           res.status(500).json({
               message: 'An error has occured',
               obj: err
           })
       }
       console.log('reply', reply);
       res.status(200).json({
           message: "you have successfully edited your reply",
           obj: reply
       })
   });

   function findReply(cb){
       ForumReply.findOne({'_id': req.body.replyId}, function(err, reply){
        cb(null, reply)
       });
   }

   function saveReply(cb) {
       reply.save(function (err, reply) {
           cb(null, reply)
       })
   }
});

router.post('/forumCountMin', function(req, res) {
   console.log('entered back-end');

    var loggedIn =  req.body.isLoggedIn;
    ForumCount.find({}, function(err, countDocs) {

        loggedIn ? countDocs[0].registered-- : countDocs[0].guests--;

        countDocs[0].save(function (err, doc) {
            if (err) {
                return res.status(500).json({
                    message: "unable to find this specific post",
                    err: err
                })
            }
            res.status(200).json({
                msg: "hellooooo"
            });
        });
    });
});

router.post('/forumCountPlus', function (req,res) {
    var loggedIn = req.body.isLoggedIn;

    ForumCount.find({}, function(err, countDocs) {

        loggedIn ? countDocs[0].registered++ : countDocs[0].guests++;
        var countTotal = countDocs[0].registered + countDocs[0].guests;

        // if there is a new total amount of users, then update the db document.
        if ( countTotal > countDocs[0].highestNumber.num) {
            countDocs[0].highestNumber.num = countTotal;
            countDocs[0].highestNumber.date = new Date();
        }
        countDocs[0].save(function (err, doc) {
            if (err) {
                return res.status(500).json({
                    message: "unable to find this specific post",
                    err: err
                })
            }

            res.status(200).json({
                registered: doc.registered,
                guests: doc.guests,
                highestNumber: {
                    num: doc.highestNumber.num,
                    date: doc.highestNumber.date
                }
            });
        });
    })
});

router.get('/getForumSectionsHomepage', function(req, res){
    console.log('entered getForum...');
    ForumSection.find({})
        .populate({
            path: 'posts',
            select: 'user title date',
            populate: {
                path: 'user',
                select: 'firstName lastName'
            }
        })
        .exec(function(err, sections){
            if (err) {
                return res.status(500).json({
                    message: "Something went wrong",
                    err: err
                });
            }
            res.status(200).json({
                message: "Successfully retrieved the section",
                obj: sections
            });
        })
});

router.get('/getPost/:id', function(req, res){
    ForumPost.findOne({'_id': req.params.id})
        .populate('user', 'username forumPosts forumReplies registerDate date')
        .populate({
            path: 'replies',
            populate: {
                path: 'user',
                select: 'username forumPosts forumReplies registerDate date'
            }
        })
        .exec(function(err, post){
            if (err) {
                return res.status(500).json({
                    message: "unable to find this specific post",
                    err: err
                })
            }
            post.totalViews++;
            post.save(function(err, post){
                if (err) {
                    return res.status(500).json({
                        message: "unable to find this specific post",
                        err: err
                    })
                }
                res.status(200).json({
                    message: "successfully received post",
                    obj: post
                });
            });
        })
});

router.get('/getPosts/:section', function(req, res) {

    ForumSection.findOne({'name': req.params.section})
        .populate({
            path: 'posts',
            populate: [{
                path: 'user',
                select: 'username replies'
            }, {
                path: 'replies',
                select: 'user date',
                populate: {
                    path: 'user',
                    select: 'username'
                }
            }]
        })
        .exec( function(err, section) {
            if (err) {
                return res.status(500).json({
                    message: "unable to find this specific section",
                    err: err
                })
            }
            res.status(200).json({
                message: "successfully received messages",
                obj: section.posts
            })
        });
});

router.get('/getReplies', function(req, res){

    ForumPost.findOne({'_id': req.body.postId})
        .populate({
            path: 'replies',
            populate: {
                path: 'user',
                select: 'username forumPosts forumReplies registerDate date'
            }
        })
        .exec(function(err, post){
            if (err) {
                res.status(500).json({
                    message: "something wrong happened",
                    err: err
                })
            }
            res.status(200).json({
                message: "successfully retrieved the messages",
                obj: post
            })
        })
});

router.get('/getSections', function(req, res){
   ForumSection.find({})
       .exec(function(err, sections){
           if (err) {
               return res.status(500).json({
                   message: "Something went wrong",
                   err: err
               });
           }
           res.status(200).json({
               message: "Successfully retrieved the section",
               obj: sections
           });
       })
});

router.get('/getSubViews', function(req, res) {

    SubViewCount.find({'section': new RegExp('quests|cities|tips & tricks|general', 'gi')}, function(err, results){
        if (err) {
            return res.status(500).json({
                message: "Something went wrong",
                err: err
            });
        }

        res.status(200).json({
            views: results
        })
    })

});

router.get('/subViewPlus/:section/:sign', function(req, res){
    SubViewCount.findOne({'section': req.params.section}, function(err, doc){
        req.params.sign === 'plus' ? doc.views++ : doc.views--;
        doc.save(function(err, doc){
            if (err) {
                return res.status(500).json({
                    message: "Something went wrong",
                    err: err
                });
            }
            res.status(200).json({
                views: doc.views
            })
        })
    })
});


module.exports = router;