var express = require('express');
var router = express.Router();
var NewsArticle = require('../models/newsArticle');

router.post('/saveNewsPost', function(req, res){
    console.log(req.body);

    var newPost = new NewsArticle({
        htmlCode: req.body
    });

    newPost.save(function(err, newsArticle){
        if (err) {
            return res.status(500).json({
                title: "An error occurred",
                error: err
            })
        }
        res.status(200).json({
            message: "Succesfully saved the newsArticle",
            obj: newsArticle
        })
    })
});


module.exports = router;